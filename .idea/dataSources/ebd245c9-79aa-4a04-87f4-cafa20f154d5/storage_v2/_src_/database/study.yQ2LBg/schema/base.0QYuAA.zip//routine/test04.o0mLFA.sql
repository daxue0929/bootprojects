create function test04(num integer) returns integer
  language plpgsql
as
$$
BEGIN
	RETURN num * 2;
END;
$$;

alter function test04(integer) owner to root;


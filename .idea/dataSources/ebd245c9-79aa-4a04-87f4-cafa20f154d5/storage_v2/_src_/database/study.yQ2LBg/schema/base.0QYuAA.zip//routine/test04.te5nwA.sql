create function test04(num integer, age integer) returns integer
  language plpgsql
as
$$
BEGIN
	RETURN num * age;
END;
$$;

alter function test04(integer, integer) owner to root;

